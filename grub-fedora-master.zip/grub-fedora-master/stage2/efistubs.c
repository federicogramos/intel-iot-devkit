
#include "shared.h"
#include "efistubs.h"

#if defined(PLATFORM_EFI)
int network_ready = 0;
#endif /* defined(PLATFORM_EFI) */
