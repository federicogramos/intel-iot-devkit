#ifndef EFISTUBS_H
#define EFISTUBS_H 1

#if defined(PLATFORM_EFI)
extern int network_ready;
#endif /* defined(PLATFORM_EFI) */

#endif /* EFISTUBS_H */
